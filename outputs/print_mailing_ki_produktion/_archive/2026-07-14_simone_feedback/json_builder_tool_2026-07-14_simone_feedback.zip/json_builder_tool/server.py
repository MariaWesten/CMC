#!/usr/bin/env python3
import cgi
import hashlib
import html
import io
import json
import os
import re
import shutil
import sys
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
BASE_JSON_CANDIDATES = [
    ROOT / "base_shape_labs_all_variants_end_to_end_data.json",
    ROOT.parent / "shape_labs_partner_automation_test" / "data" / "shape_labs_all_variants_end_to_end_data.json",
]
ASSET_EXPORT_DIR = ROOT / "assets_partner"
PROMPTSET_PATH = ROOT / "promptset_layoutvarianten_v02.md"
PORT = int(os.environ.get("CMC_JSON_BUILDER_PORT", "8766"))

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".psd", ".eps", ".svg", ".webp"}
TEXT_EXTS = {".txt", ".md", ".csv", ".json", ".html", ".htm", ".xml"}
OFFICE_EXTS = {".docx", ".xlsx", ".pptx"}
URL_EXCLUDED_HOST_PARTS = {
    "sharepoint.com",
    "microsoft.com",
    "office.com",
    "office365.com",
    "forms.office.com",
    "adobe.com",
    "google.com",
    "openxmlformats.org",
    "w3.org",
    "xmlsoap.org",
    "purl.org",
    "dublincore.org",
}
REQUIRED_TEXT_FIELDS = [
    "partner_name",
    "customer_group_term",
    "partner_adress",
    "offer_disclaimer",
    "front_salutation",
    "a_front_copy",
    "partner_url",
    "offer_value_amount",
    "offer_value_friends_amount",
    "offer_value_type",
    "sender_name",
    "quote_1",
    "name_quote_1",
    "quote_2",
    "name_quote_2",
    "dicscount_cta",
    "b_back_quote_mood",
    "d_front_quote",
    "d_back_headline",
    "d_back_quote",
]
FIXED_INPUT_FIELDS = [
    "partner_name",
    "customer_group_term",
    "Vorname",
    "Nachname",
    "partner_url",
    "offer_value_amount",
    "offer_value_friends_amount",
    "offer_value_type",
    "friend_offer_value_amount",
]
TEMPLATE_ONLY_TEXT_FIELDS = [
    "a_front_headline",
    "a_back_product_headline",
    "a_back_quote_headline",
    "b_headline_CTA",
    "c_front_headline",
    "c_back_product_headline",
]
REQUIRED_IMAGE_SLOTS = [
    "partner_logo",
    "sender_image",
    "img_mood_product",
    "img_product_1",
]
FIELD_LABELS = {
    "partner_name": "Markenname",
    "customer_group_term": "Kundenansprache / Gender-Wording",
    "partner_adress": "Absenderzeile",
    "offer_disclaimer": "Sternchentext / Pflichttext",
    "front_salutation": "Anrede",
    "a_front_headline": "Variante A: Headline",
    "a_front_copy": "Variante A: Anschreiben",
    "partner_url": "Shop-URL",
    "offer_value_amount": "Gutschein-/Rabattwert",
    "offer_value_friends_amount": "Freunde-/Empfehlungswert",
    "offer_value_type": "Gutschein-/Rabattart",
    "friend_offer_value_amount": "Freunde-/Empfehlungswert",
    "sender_name": "Absendername",
    "a_back_quote_headline": "Variante A: Zitat-Headline",
    "quote_1": "Kundenzitat 1",
    "name_quote_1": "Name zu Kundenzitat 1",
    "quote_2": "Kundenzitat 2",
    "name_quote_2": "Name zu Kundenzitat 2",
    "dicscount_cta": "CTA mit Rabattnennung",
    "b_headline_CTA": "Variante B: CTA-Headline",
    "b_sub_headline_CTA": "Variante B: CTA-Subline",
    "b_back_quote_mood": "Variante B: emotionaler Abschluss",
    "c_front_headline": "Variante C: Headline",
    "c_front_copy": "Variante C: Copy",
    "c_back_product_headline": "Variante C: Rückseiten-Headline",
    "d_front_quote": "Variante D: Absenderzitat Vorderseite",
    "d_back_headline": "Variante D: Rückseiten-Headline",
    "d_back_quote": "Variante D: Rückseiten-Zitat",
    "partner_logo": "Logo",
    "sender_image": "Absenderbild",
    "img_mood_product": "Moodbild Produkt",
    "img_product_1": "Produktbild 1",
}
TEXT_RULES = {
    "usp_1": {"max": 42, "label": "USP 1"},
    "usp_2": {"max": 42, "label": "USP 2"},
    "usp_3": {"max": 42, "label": "USP 3"},
    "partner_adress": {"max": 80, "label": "Absenderzeile"},
    "offer_disclaimer": {"label": "Sternchentext"},
    "a_front_headline": {"max": 47, "label": "A Headline"},
    "a_front_copy": {"min": 600, "max": 700, "label": "A Anschreiben"},
    "partner_claim": {"max": 45, "label": "Markenbotschaft"},
    "a_back_product_headline": {"max": 50, "label": "A Rückseite Headline"},
    "product_name_1": {"max": 45, "label": "Produkt 1 Titel"},
    "product_description_1": {"max": 100, "label": "Produkt 1 Beschreibung"},
    "product_bullet_points_1": {"max": 100, "label": "Produkt 1 Bulletpoints"},
    "product_name_2": {"max": 45, "label": "Produkt 2 Titel"},
    "product_description_2": {"max": 100, "label": "Produkt 2 Beschreibung"},
    "product_bullet_points_2": {"max": 100, "label": "Produkt 2 Bulletpoints"},
    "product_name_3": {"max": 45, "label": "Produkt 3 Titel"},
    "product_description_3": {"max": 100, "label": "Produkt 3 Beschreibung"},
    "product_bullet_points_3": {"max": 100, "label": "Produkt 3 Bulletpoints"},
    "product_name_4": {"max": 45, "label": "Produkt 4 Titel"},
    "product_description_4": {"max": 100, "label": "Produkt 4 Beschreibung"},
    "product_name_5": {"max": 45, "label": "Produkt 5 Titel"},
    "product_description_5": {"max": 100, "label": "Produkt 5 Beschreibung"},
    "product_name_6": {"max": 45, "label": "Produkt 6 Titel"},
    "product_description_6": {"max": 100, "label": "Produkt 6 Beschreibung"},
    "a_back_quote_headline": {"max": 50, "label": "A Zitat-Headline"},
    "b_front_headline": {"max": 60, "label": "B Headline"},
    "b_front_copy": {"max": 530, "label": "B Copy"},
    "b_headline_CTA": {"max": 55, "label": "B CTA-Headline"},
    "b_sub_headline_CTA": {"max": 85, "label": "B CTA-Subline"},
    "b_back_quote_mood": {"max": 55, "label": "B Emotionaler Abschluss"},
    "c_front_headline": {"max": 30, "label": "C Headline"},
    "c_front_copy": {"min": 270, "max": 310, "label": "C Copy"},
    "c_back_product_headline": {"max": 50, "label": "C Rückseite Headline"},
    "d_front_pre_headline": {"max": 45, "label": "D Pre-Headline"},
    "d_front_headline": {"max": 70, "label": "D Headline"},
    "d_front_thx": {"max": 190, "label": "D Danke-Text"},
    "d_front_article1_headline": {"max": 50, "label": "D Artikel 1 Headline"},
    "d_front_article1_body_copy": {"max": 390, "label": "D Artikel 1"},
    "d_front_article2_headline": {"max": 50, "label": "D Artikel 2 Headline"},
    "d_front_article2_body_copy": {"max": 220, "label": "D Artikel 2"},
    "d_front_quote": {"max": 220, "label": "D Zitat Vorderseite"},
    "d_back_headline": {"max": 35, "label": "D Rückseite Headline"},
    "d_back_quote": {"max": 380, "label": "D Rückseite Zitat"},
}
IMAGE_ALIASES = {
    "partner_logo": ["partner_logo", "logo", "marke", "brand"],
    "sender_image": ["sender_image", "absender", "profil", "portrait"],
    "sender_image_mood": ["sender_image_mood", "absender_mood", "profil", "portrait"],
    "img_mood_product": ["img_mood_product", "mood_product", "produkt_mood", "mood_first_page", "first_page", "hero"],
    "img_mood_product_use": ["img_mood_product_use", "anwendung", "product_use"],
    "img_mood_emotion": ["img_mood_emotion", "emotion", "mensch"],
    "img_mood_product_emotion": ["img_mood_product_emotion", "product_emotion"],
    "img_mood_article": ["img_mood_article", "article", "editorial"],
    "img_quote_1": ["img_quote_1", "quote_1", "zitat_1", "kundenzitat_1", "portrait_1"],
    "img_quote_2": ["img_quote_2", "quote_2", "zitat_2", "kundenzitat_2", "portrait_2"],
    "qr_code_1": ["qr_code_1", "qr1", "qr_1"],
    "qr_code_2": ["qr_code_2", "qr2", "qr_2"],
}
IMAGE_SLOT_COUNTS = {}

for i in range(1, 7):
    IMAGE_ALIASES[f"img_product_{i}"] = [f"img_product_{i}", f"produkt_{i}", f"product_{i}", f"p{i}"]


def load_base_data():
    for path in BASE_JSON_CANDIDATES:
        if path.exists():
            with path.open("r", encoding="utf-8") as f:
                return json.load(f)
    raise FileNotFoundError("Basis-JSON nicht gefunden: " + ", ".join(str(p) for p in BASE_JSON_CANDIDATES))


def load_prompt_set():
    if PROMPTSET_PATH.exists():
        return PROMPTSET_PATH.read_text(encoding="utf-8")
    return ""


def normalize_name(value):
    value = value.lower()
    value = value.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    value = re.sub(r"[^a-z0-9]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    return value


def safe_asset_name(original_name, used_names):
    base = Path(original_name).stem
    suffix = Path(original_name).suffix.lower()
    normalized = normalize_name(base) or "bild"
    candidate = normalized + suffix
    counter = 2
    while candidate in used_names:
        candidate = normalized + "_" + str(counter) + suffix
        counter += 1
    used_names.add(candidate)
    return candidate


def scan_zip(raw_zip, upload_name="partner.zip"):
    image_files = []
    other_files = []
    used_asset_names = set()
    partner_asset_dir = ASSET_EXPORT_DIR / (normalize_name(Path(upload_name).stem) or "partner")
    if partner_asset_dir.exists():
        shutil.rmtree(partner_asset_dir)
    partner_asset_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(raw_zip)) as zf:
        for name in zf.namelist():
            if name.endswith("/") or name.startswith("__MACOSX/"):
                continue
            suffix = Path(name).suffix.lower()
            entry = {
                "path": name,
                "name": Path(name).name,
                "normalized": normalize_name(Path(name).stem),
            }
            if suffix in IMAGE_EXTS:
                asset_name = safe_asset_name(Path(name).name, used_asset_names)
                asset_path = partner_asset_dir / asset_name
                with zf.open(name) as source, asset_path.open("wb") as target:
                    shutil.copyfileobj(source, target)
                entry["asset_name"] = asset_name
                entry["asset_path"] = str(asset_path)
                entry["content_hash"] = hashlib.sha1(asset_path.read_bytes()).hexdigest()
                image_files.append(entry)
            else:
                other_files.append(entry)
    return image_files, other_files


def extract_text_from_office_bytes(raw):
    chunks = []
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as office_zip:
            for nested_name in office_zip.namelist():
                if not nested_name.lower().endswith((".xml", ".rels")):
                    continue
                try:
                    chunks.append(office_zip.read(nested_name).decode("utf-8", errors="ignore"))
                except Exception:
                    continue
    except zipfile.BadZipFile:
        return ""
    return "\n".join(chunks)


def normalize_url_candidate(value):
    value = html.unescape(str(value or "")).strip()
    value = value.rstrip(".,;:!?)]}'\"")
    if value.lower().startswith("www."):
        value = "https://" + value
    if not value.lower().startswith(("http://", "https://")):
        value = "https://" + value
    parsed = urlparse(value)
    host = (parsed.netloc or "").lower()
    if not host or "." not in host:
        return ""
    if any(blocked in host for blocked in URL_EXCLUDED_HOST_PARTS):
        return ""
    return value


def extract_website_candidates(raw_zip):
    candidates = []
    seen = set()
    url_pattern = re.compile(
        r"(?:https?://|www\.)[^\s<>\"]+|(?<![@\w])(?:[a-z0-9-]+\.)+(?:de|com|net|org|shop|store|bio|one)(?:/[^\s<>\"]*)?",
        re.IGNORECASE,
    )
    try:
        with zipfile.ZipFile(io.BytesIO(raw_zip)) as zf:
            for name in zf.namelist():
                if name.endswith("/") or name.startswith("__MACOSX/"):
                    continue
                suffix = Path(name).suffix.lower()
                if suffix not in TEXT_EXTS and suffix not in OFFICE_EXTS:
                    continue
                try:
                    raw = zf.read(name)
                except Exception:
                    continue
                if suffix in OFFICE_EXTS:
                    text = extract_text_from_office_bytes(raw)
                else:
                    text = raw.decode("utf-8", errors="ignore")
                for match in url_pattern.findall(text):
                    candidate = normalize_url_candidate(match)
                    if not candidate or candidate in seen:
                        continue
                    seen.add(candidate)
                    candidates.append(candidate)
    except zipfile.BadZipFile:
        return []
    candidates.sort(key=lambda value: (urlparse(value).path not in ("", "/"), len(value)))
    return candidates[:20]


def auto_map_images(image_files, image_slots):
    mapping = {}
    used = set()
    used_mood_hashes = set()
    ordered_slots = sorted(image_slots, key=slot_specificity_score, reverse=True)
    for slot in ordered_slots:
        aliases = IMAGE_ALIASES.get(slot, [slot])
        aliases = [normalize_name(a) for a in aliases]
        needed_count = IMAGE_SLOT_COUNTS.get(slot, 1)
        chosen = []
        for image in sorted(image_files, key=lambda item: best_image_score(item["normalized"], aliases)):
            if image["path"] in used:
                continue
            if slot.startswith("img_mood_") and image.get("content_hash") in used_mood_hashes:
                continue
            if best_image_score(image["normalized"], aliases) < 1000:
                chosen.append(image)
                used.add(image["path"])
                if slot.startswith("img_mood_"):
                    used_mood_hashes.add(image.get("content_hash"))
            if len(chosen) >= needed_count:
                break
        if slot.startswith("img_mood_") and len(chosen) < needed_count:
            for image in image_files:
                if image["path"] in used or image.get("content_hash") in used_mood_hashes:
                    continue
                if "mood" not in image["normalized"] and "banner" not in image["normalized"]:
                    continue
                chosen.append(image)
                used.add(image["path"])
                used_mood_hashes.add(image.get("content_hash"))
                if len(chosen) >= needed_count:
                    break
        if chosen:
            paths = [image["asset_path"] for image in chosen]
            mapping[slot] = paths if needed_count > 1 else paths[0]
    return mapping


def resolve_known_image_paths(image_data, image_files):
    resolved = {}
    by_name = {}
    for image in image_files:
        by_name.setdefault(Path(image["name"]).name.lower(), image["asset_path"])
        by_name.setdefault(Path(image["asset_name"]).name.lower(), image["asset_path"])
    for slot, value in (image_data or {}).items():
        values = value if isinstance(value, list) else [value]
        matched = []
        for path in values:
            asset_path = by_name.get(Path(str(path)).name.lower())
            if asset_path:
                matched.append(asset_path)
        if matched:
            resolved[slot] = matched if isinstance(value, list) else matched[0]
    return resolved


def slot_specificity_score(slot):
    aliases = IMAGE_ALIASES.get(slot, [slot])
    return max(len(normalize_name(alias)) for alias in aliases if alias)


def best_image_score(normalized_name, aliases):
    scores = []
    for alias in aliases:
        if not alias:
            continue
        if normalized_name == alias:
            scores.append(0)
        elif normalized_name.startswith(alias):
            scores.append(1)
        elif alias in normalized_name:
            scores.append(2)
    return min(scores) if scores else 1000


class Handler(BaseHTTPRequestHandler):
    def _send(self, status, body, content_type="text/html; charset=utf-8"):
        encoded = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            self._send(200, INDEX_HTML)
            return
        if path in ("/favicon.svg", "/favicon.ico"):
            self._send(200, FAVICON_SVG, "image/svg+xml; charset=utf-8")
            return
        self._send(404, "Nicht gefunden")

    def do_POST(self):
        if self.path != "/api/analyze":
            self._send(404, "Nicht gefunden")
            return

        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={
                "REQUEST_METHOD": "POST",
                "CONTENT_TYPE": self.headers.get("Content-Type", ""),
            },
        )
        if "partner_zip" not in form:
            self._send(400, json.dumps({"error": "Keine ZIP-Datei gefunden."}), "application/json; charset=utf-8")
            return

        uploaded_zip = form["partner_zip"]
        raw = uploaded_zip.file.read()
        try:
            image_files, other_files = scan_zip(raw, uploaded_zip.filename or "partner.zip")
            website_candidates = extract_website_candidates(raw)
            base = load_base_data()
            image_slots = sorted(set((base.get("images") or {}).keys()) | set(IMAGE_ALIASES.keys()))
            resolved_images = resolve_known_image_paths(base.get("images") or {}, image_files)
            automatic_images = auto_map_images(image_files, image_slots)
            automatic_images.update(resolved_images)
            base["images"] = automatic_images
            result = {
                "baseData": base,
                "imageFiles": image_files,
                "otherFiles": other_files[:200],
                "imageSlots": image_slots,
                "warnings": build_warnings(base, image_files),
                "textRules": TEXT_RULES,
                "requiredTextFields": REQUIRED_TEXT_FIELDS,
                "fixedInputFields": FIXED_INPUT_FIELDS,
                "templateOnlyTextFields": TEMPLATE_ONLY_TEXT_FIELDS,
                "requiredImageSlots": REQUIRED_IMAGE_SLOTS,
                "fieldLabels": FIELD_LABELS,
                "imageSlotCounts": IMAGE_SLOT_COUNTS,
                "promptSet": load_prompt_set(),
                "websiteCandidates": website_candidates,
            }
            self._send(200, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
        except zipfile.BadZipFile:
            self._send(400, json.dumps({"error": "Die Datei konnte nicht als ZIP gelesen werden."}), "application/json; charset=utf-8")
        except Exception as exc:
            self._send(500, json.dumps({"error": str(exc)}), "application/json; charset=utf-8")

    def log_message(self, fmt, *args):
        sys.stderr.write("%s\n" % (fmt % args))


def build_warnings(data, image_files):
    warnings = []
    text = data.get("text", {})
    for key in REQUIRED_TEXT_FIELDS:
        if not str(text.get(key, "")).strip():
            warnings.append(f"Pflichtfeld fehlt oder ist leer: {key}")
    for key, rule in TEXT_RULES.items():
        value = str(text.get(key, ""))
        length_value = resolve_placeholders_for_length(value, text)
        if rule.get("min") and value and len(length_value) < rule["min"]:
            warnings.append(f"{rule.get('label', key)} wirkt zu kurz: Ziel {rule['min']}-{rule.get('max', 'offen')} Zeichen.")
        if rule.get("max") and len(length_value) > rule["max"]:
            warnings.append(f"{rule.get('label', key)} ist zu lang: Ziel max. {rule['max']} Zeichen.")
    for key in ("usp_1", "usp_2", "usp_3"):
        if str(text.get(key, "")).startswith(" "):
            warnings.append(f"{key} beginnt mit Leerzeichen.")
    serialized = json.dumps(text, ensure_ascii=False)
    placeholder_scan = serialized.replace("[Vorname]", "")
    for allowed in (
        "{{offer_value_amount}}",
        "{{offer_value_type}}",
        "{{partner_url}}",
        "{{partner_name}}",
        "{{customer_group_term}}",
        "{{sender_firstname}}",
        "{{sender_surname}}",
        "{{Vorname}}",
        "{{Nachname}}",
    ):
        placeholder_scan = placeholder_scan.replace(allowed, "")
    if re.search(r"\{\{[^}]+\}\}", placeholder_scan) or re.search(r"\[[^\]]+\]", placeholder_scan):
        warnings.append("Es sind noch sichtbare Platzhalter im Text vorhanden. Bitte prüfen.")
    if "\n\n" in json.dumps(text, ensure_ascii=False):
        warnings.append("Ein Textfeld enthält doppelte Umbrüche. Bitte vor Export prüfen.")
    if not image_files:
        warnings.append("Keine Bilddateien im ZIP gefunden.")
    return warnings


def resolve_placeholders_for_length(value, text):
    resolved = str(value or "")
    for key, replacement in (text or {}).items():
        if isinstance(replacement, (dict, list)):
            continue
        resolved = resolved.replace("{{" + str(key) + "}}", str(replacement or ""))
        resolved = resolved.replace("[" + str(key) + "]", str(replacement or ""))
    return resolved


INDEX_HTML = r"""<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CMC Mailing-Assistent</title>
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <style>
    :root { --ink:#183f47; --line:#d9e2e4; --soft:#f4f7f7; --accent:#2f8f83; --warn:#8a5b00; }
    body { margin:0; font:14px/1.45 Arial, sans-serif; color:#1f2d32; background:#f7f8f8; }
    header { padding:18px 24px; background:#fff; border-bottom:1px solid var(--line); position:sticky; top:0; z-index:1; }
    h1 { margin:0; color:var(--ink); font-size:22px; }
    main { max-width:1280px; margin:0 auto; padding:22px; display:grid; gap:18px; }
    section { background:#fff; border:1px solid var(--line); border-radius:8px; padding:18px; }
    h2 { margin:0 0 12px; color:var(--ink); font-size:18px; }
    h3 { margin:18px 0 8px; color:var(--ink); font-size:15px; }
    button { border:0; border-radius:6px; background:var(--ink); color:white; padding:10px 14px; cursor:pointer; font-weight:bold; }
    button.secondary { background:var(--accent); }
    input[type=file] { display:block; margin:10px 0 14px; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:18px; }
    .control-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    .field { margin:10px 0; }
    label { display:block; font-weight:bold; margin-bottom:4px; color:#2d454b; }
    textarea, input, select { width:100%; box-sizing:border-box; border:1px solid var(--line); border-radius:6px; padding:8px; font:13px/1.35 Arial, sans-serif; }
    textarea { min-height:74px; resize:vertical; }
    .small { color:#66777d; font-size:12px; }
    .muted-box { background:#f4f7f7; border:1px solid var(--line); border-radius:6px; padding:10px; margin:8px 0; }
    .warn { color:var(--warn); background:#fff8e8; border:1px solid #f0d38c; padding:8px 10px; border-radius:6px; margin:6px 0; }
    .ok { color:#166348; background:#eaf7f2; border:1px solid #bde2d4; padding:8px 10px; border-radius:6px; margin:6px 0; }
    .danger { color:#7f1d1d; background:#fff0f0; border:1px solid #f0b8b8; padding:8px 10px; border-radius:6px; margin:6px 0; }
    .badge { display:inline-block; border-radius:999px; padding:2px 8px; font-size:11px; margin-left:8px; vertical-align:middle; }
    .badge.ok { border:1px solid #bde2d4; padding:2px 8px; margin-left:8px; }
    .badge.warn { border:1px solid #f0d38c; padding:2px 8px; margin-left:8px; }
    .badge.danger { border:1px solid #f0b8b8; padding:2px 8px; margin-left:8px; }
    .field-meta { color:#66777d; font-size:12px; margin:3px 0 6px; }
    .slotrow { display:grid; grid-template-columns:220px 1fr; gap:10px; align-items:center; margin:8px 0; }
    .actions { display:flex; gap:10px; flex-wrap:wrap; }
    pre { white-space:pre-wrap; background:#0f272d; color:#e7f6f4; border-radius:8px; padding:14px; max-height:280px; overflow:auto; }
    @media (max-width:900px) { .grid, .control-grid { grid-template-columns:1fr; } .slotrow { grid-template-columns:1fr; } }
  </style>
</head>
<body>
  <header>
    <h1>CMC Mailing-Assistent</h1>
    <div class="small">Partnerdaten vorbereiten, KI-Texte übernehmen, Bilder zuordnen und InDesign-JSON exportieren.</div>
  </header>
  <main>
    <section>
      <h2>1. Partner-ZIP laden</h2>
      <input id="zipInput" type="file" accept=".zip">
      <button id="analyzeBtn">ZIP analysieren</button>
      <span id="status" class="small"></span>
    </section>

    <section id="textGenerationSection" style="display:none">
      <h2>2. KI-Texte erstellen</h2>
      <div class="control-grid">
        <div class="field">
          <label for="websiteUrl">Website des Partners</label>
          <input id="websiteUrl" type="url" placeholder="https://www.partner.de">
        </div>
        <div class="field">
          <label for="toneNotes">Partnerspezifische Textvorgaben</label>
          <textarea id="toneNotes" placeholder="Zum Beispiel: sachlicher als üblich, keine Superlative, Produktname immer ausschreiben."></textarea>
        </div>
        <div class="field">
          <label for="mustUse">Verbindliche Begriffe und Botschaften</label>
          <textarea id="mustUse" placeholder="Begriffe, Claims oder Argumente, die verwendet werden sollen."></textarea>
        </div>
        <div class="field">
          <label for="noGos">Nicht verwenden</label>
          <textarea id="noGos" placeholder="Nicht zulässige Begriffe, Claims oder Formulierungen."></textarea>
        </div>
      </div>
      <div class="field">
        <label for="websiteSample">Optional: Beispieltext von der Website</label>
        <textarea id="websiteSample" placeholder="Ein kurzer Originaltext hilft, wenn die Website im KI-Chat nicht aufgerufen werden kann."></textarea>
      </div>
      <h3>Optional: Vorgaben je Variante</h3>
      <div class="control-grid">
        <div class="field">
          <label for="variantNotesA">A – Klassischer Werbebrief</label>
          <textarea id="variantNotesA" placeholder="Nur ausfüllen, wenn A zusätzlich anders gesteuert werden soll."></textarea>
        </div>
        <div class="field">
          <label for="variantNotesB">B – Visual Storytelling</label>
          <textarea id="variantNotesB" placeholder="Zum Beispiel: stärker über Gründerstory und Alltagssituation erzählen."></textarea>
        </div>
        <div class="field">
          <label for="variantNotesC">C – Snackable</label>
          <textarea id="variantNotesC" placeholder="Zum Beispiel: Angebot maximal direkt und verkaufsorientiert formulieren."></textarea>
        </div>
        <div class="field">
          <label for="variantNotesD">D – Editorial</label>
          <textarea id="variantNotesD" placeholder="Zum Beispiel: Herkunft und Produktkompetenz vertiefen."></textarea>
        </div>
      </div>
      <div class="muted-box">Den Textauftrag zusammen mit dem Partner-ZIP im freigegebenen KI-Chat verwenden. In den Mailing-Assistenten wird anschließend ausschließlich das JSON-Ergebnis importiert.</div>
      <div class="actions">
        <button id="downloadPromptBtn">KI-Textauftrag herunterladen</button>
        <button class="secondary" id="copyPromptBtn">KI-Textauftrag kopieren</button>
      </div>
      <h3>KI-Ergebnis übernehmen</h3>
      <div class="field">
        <label for="aiJsonPaste">JSON-Antwort aus dem KI-Chat einfügen</label>
        <textarea id="aiJsonPaste" rows="8" placeholder="Die vollständige JSON-Antwort aus dem KI-Chat hier einfügen."></textarea>
      </div>
      <button class="secondary" id="importAiJsonPasteBtn">Eingefügtes JSON übernehmen</button>
      <div class="small" style="margin-top:12px">Alternativ kann eine bereits gespeicherte JSON-Datei ausgewählt werden:</div>
      <input id="aiJsonInput" type="file" accept=".json,application/json">
      <button class="secondary" id="importAiJsonBtn">JSON-Ergebnis importieren</button>
      <span id="aiImportStatus" class="small"></span>
    </section>

    <section id="reviewSection" style="display:none">
      <h2>3. Prüfung und Zuordnung</h2>
      <div id="warnings"></div>
      <div class="grid">
        <div>
          <h3>Texte</h3>
          <div id="textFields"></div>
        </div>
        <div>
          <h3>Bilder</h3>
          <div class="small">Bilder werden automatisch vorgeschlagen, wenn die Datei eindeutig zu einem Slot passt. Bitte die Zuordnung trotzdem fachlich prüfen.</div>
          <div id="imageFields"></div>
        </div>
      </div>
      <h3>Partner-Rückfrage</h3>
      <textarea id="partnerEmail" rows="8" readonly></textarea>
      <div class="actions">
        <button id="copyEmailBtn">Rückfrage-Text kopieren</button>
      </div>
      <h3>Export</h3>
      <div class="actions">
        <button class="secondary" id="downloadBtn">JSON herunterladen</button>
        <button id="downloadReportBtn">Checkreport herunterladen</button>
        <button id="previewBtn">JSON-Vorschau aktualisieren</button>
      </div>
      <pre id="jsonPreview"></pre>
    </section>
  </main>
  <script>
    let currentData = null;
    let imageFiles = [];
    let imageSlots = [];
    let textRules = {};
    let requiredTextFields = [];
    let fixedInputFields = [];
    let templateOnlyTextFields = [];
    let requiredImageSlots = [];
    let fieldLabels = {};
    let imageSlotCounts = {};
    let promptSet = "";
    let currentUploadName = "";
    let websiteCandidates = [];

    const byId = (id) => document.getElementById(id);

    byId("analyzeBtn").addEventListener("click", async () => {
      const file = byId("zipInput").files[0];
      if (!file) {
        alert("Bitte zuerst eine ZIP-Datei auswählen.");
        return;
      }
      byId("status").textContent = "Analysiere ZIP ...";
      const form = new FormData();
      form.append("partner_zip", file);
      const res = await fetch("/api/analyze", { method: "POST", body: form });
      const payload = await res.json();
      if (!res.ok) {
        alert(payload.error || "Analyse fehlgeschlagen.");
        byId("status").textContent = "";
        return;
      }
      currentData = payload.baseData;
      currentUploadName = file.name;
      imageFiles = payload.imageFiles || [];
      imageSlots = payload.imageSlots || [];
      textRules = payload.textRules || {};
      requiredTextFields = payload.requiredTextFields || [];
      fixedInputFields = payload.fixedInputFields || [];
      templateOnlyTextFields = payload.templateOnlyTextFields || [];
      requiredImageSlots = payload.requiredImageSlots || [];
      fieldLabels = payload.fieldLabels || {};
      imageSlotCounts = payload.imageSlotCounts || {};
      promptSet = payload.promptSet || "";
      websiteCandidates = payload.websiteCandidates || [];
      if (!byId("websiteUrl").value.trim() && websiteCandidates.length) {
        byId("websiteUrl").value = websiteCandidates[0];
      }
      renderTextFields();
      renderImageFields();
      renderChecks();
      byId("textGenerationSection").style.display = "block";
      byId("reviewSection").style.display = "block";
      byId("status").textContent = "Analyse abgeschlossen.";
    });

    function renderWarnings(checks) {
      const box = byId("warnings");
      box.innerHTML = "";
      const warnings = checks.warnings || [];
      const errors = checks.errors || [];
      if (!warnings.length && !errors.length) {
        box.innerHTML = '<div class="ok">Keine automatischen Warnungen. Bitte trotzdem fachlich prüfen.</div>';
        return;
      }
      errors.forEach(w => {
        const div = document.createElement("div");
        div.className = "danger";
        div.textContent = w;
        box.appendChild(div);
      });
      warnings.forEach(w => {
        const div = document.createElement("div");
        div.className = "warn";
        div.textContent = w;
        box.appendChild(div);
      });
    }

    function renderTextFields() {
      const wrap = byId("textFields");
      wrap.innerHTML = "";
      Object.entries(currentData.text || {}).forEach(([key, value]) => {
        const div = document.createElement("div");
        div.className = "field";
        const label = document.createElement("label");
        const labelText = document.createElement("span");
        labelText.textContent = key;
        const badge = document.createElement("span");
        badge.className = "badge";
        label.appendChild(labelText);
        label.appendChild(badge);
        const meta = document.createElement("div");
        meta.className = "field-meta";
        const textarea = document.createElement("textarea");
        textarea.value = value || "";
        textarea.dataset.key = key;
        textarea.addEventListener("input", () => {
          currentData.text[key] = textarea.value;
          updateTextFieldStatus(key, textarea.value, badge, meta);
          renderChecks();
        });
        div.appendChild(label);
        div.appendChild(meta);
        div.appendChild(textarea);
        wrap.appendChild(div);
        updateTextFieldStatus(key, value || "", badge, meta);
      });
    }

    function renderImageFields() {
      const wrap = byId("imageFields");
      wrap.innerHTML = "";
      const options = ['<option value="">-- nicht zugeordnet --</option>']
        .concat(imageFiles.map(f => '<option value="' + escapeHtml(f.asset_path || "") + '">' + escapeHtml(f.path) + '</option>'))
        .join("");
      imageSlots.forEach(slot => {
        const row = document.createElement("div");
        row.className = "slotrow";
        const label = document.createElement("label");
        label.textContent = slot;
        const group = document.createElement("div");
        const count = imageSlotCounts[slot] || 1;
        const currentImageValue = (currentData.images || {})[slot] || "";
        for (let i = 0; i < count; i++) {
          const select = document.createElement("select");
          select.innerHTML = options;
          select.dataset.slot = slot;
          select.dataset.index = String(i);
          select.style.marginBottom = "6px";
          select.value = Array.isArray(currentImageValue) ? (currentImageValue[i] || "") : (i === 0 ? currentImageValue : "");
          select.addEventListener("change", () => updateImageSlotFromSelects(slot));
          group.appendChild(select);
          if (count > 1) {
            const hint = document.createElement("div");
            hint.className = "small";
            hint.textContent = "Bild " + (i + 1) + " von " + count;
            group.appendChild(hint);
          }
        }
        row.appendChild(label);
        row.appendChild(group);
        wrap.appendChild(row);
      });
    }

    function updateImageSlotFromSelects(slot) {
      currentData.images = currentData.images || {};
      const selects = Array.from(document.querySelectorAll('select[data-slot="' + slot + '"]'));
      const values = selects.map(select => select.value).filter(Boolean);
      if (!values.length) {
        delete currentData.images[slot];
      } else if ((imageSlotCounts[slot] || 1) > 1) {
        currentData.images[slot] = values;
      } else {
        currentData.images[slot] = values[0];
      }
      renderChecks();
    }

    function textStatus(key, value) {
      const resolvedValue = resolvePlaceholdersForLength(value);
      const length = resolvedValue.length;
      const rule = textRules[key] || {};
      const isRequired = requiredTextFields.includes(key);
      if (isRequired && !String(value || "").trim()) {
        return { level: "danger", text: "fehlt", meta: length + " Zeichen" };
      }
      if (fixedInputFields.includes(key)) {
        return { level: "ok", text: "fix", meta: length + " Zeichen, fixer Input / Platzhalterwert" };
      }
      if (templateOnlyTextFields.includes(key)) {
        return { level: "ok", text: "Template", meta: "Template-Text bleibt erhalten, nur Platzhalter werden ersetzt" };
      }
      if (String(value || "").startsWith(" ")) {
        return { level: "warn", text: "Leerzeichen", meta: length + " Zeichen" };
      }
      if (rule.min && String(value || "").trim() && length < rule.min) {
        return { level: "warn", text: "zu kurz", meta: length + " Zeichen, Ziel mind. " + rule.min + (rule.max ? ", maximal " + rule.max : "") };
      }
      if (rule.max && length > rule.max) {
        return { level: "warn", text: "zu lang", meta: length + " Zeichen, maximal " + rule.max };
      }
      if (rule.max) {
        return { level: "ok", text: "ok", meta: length + " Zeichen, maximal " + rule.max };
      }
      return { level: "ok", text: "gefüllt", meta: length + " Zeichen" };
    }

    function resolvePlaceholdersForLength(value) {
      let resolved = String(value || "");
      const text = currentData && currentData.text ? currentData.text : {};
      Object.entries(text).forEach(([key, replacement]) => {
        if (replacement === null || typeof replacement === "object") return;
        resolved = resolved.replaceAll("{{" + key + "}}", String(replacement || ""));
        resolved = resolved.replaceAll("[" + key + "]", String(replacement || ""));
      });
      return resolved;
    }

    function updateTextFieldStatus(key, value, badge, meta) {
      const status = textStatus(key, value);
      badge.className = "badge " + status.level;
      badge.textContent = status.text;
      meta.textContent = status.meta;
    }

    function analyzeCurrentData() {
      const errors = [];
      const warnings = [];
      const missingForPartner = [];
      const text = currentData.text || {};
      const images = currentData.images || {};

      requiredTextFields.forEach(key => {
        if (!String(text[key] || "").trim()) {
          errors.push("Pflichtfeld fehlt oder ist leer: " + key);
          missingForPartner.push("Text/Information fehlt: " + fieldLabel(key));
        }
      });

      requiredImageSlots.forEach(slot => {
        if (!images[slot]) {
          errors.push("Pflichtbild fehlt oder ist nicht zugeordnet: " + slot);
          missingForPartner.push("Bild fehlt oder ist nicht zugeordnet: " + fieldLabel(slot));
        }
      });

      Object.entries(textRules).forEach(([key, rule]) => {
        if (templateOnlyTextFields.includes(key)) return;
        const value = String(text[key] || "");
        const resolvedValue = resolvePlaceholdersForLength(value);
        if (rule.min && value && resolvedValue.length < rule.min) {
          warnings.push((rule.label || key) + " wirkt zu kurz: " + resolvedValue.length + " Zeichen, Ziel " + rule.min + "-" + (rule.max || "offen") + ".");
        }
        if (rule.max && resolvedValue.length > rule.max) {
          warnings.push((rule.label || key) + " ist zu lang: " + resolvedValue.length + " Zeichen, Ziel max. " + rule.max + ".");
        }
      });

      ["usp_1", "usp_2", "usp_3"].forEach(key => {
        if (String(text[key] || "").startsWith(" ")) {
          warnings.push(key + " beginnt mit einem Leerzeichen.");
        }
      });

      const serialized = JSON.stringify(text).replaceAll("[Vorname]", "");
      const placeholderScan = serialized
        .replaceAll("{{offer_value_amount}}", "")
        .replaceAll("{{offer_value_type}}", "")
        .replaceAll("{{partner_url}}", "")
        .replaceAll("{{partner_name}}", "")
        .replaceAll("{{customer_group_term}}", "")
        .replaceAll("{{sender_firstname}}", "")
        .replaceAll("{{sender_surname}}", "")
        .replaceAll("{{Vorname}}", "")
        .replaceAll("{{Nachname}}", "");
      if (/\{\{[^}]+\}\}/.test(placeholderScan) || /\[[^\]]+\]/.test(placeholderScan)) {
        warnings.push("Es sind noch sichtbare Platzhalter im Text vorhanden. Bitte prüfen.");
      }
      if (JSON.stringify(text).includes("\\n\\n")) {
        warnings.push("Ein Textfeld enthält doppelte Umbrüche.");
      }

      const imageValues = {};
      Object.entries(images).forEach(([slot, value]) => {
        const values = Array.isArray(value) ? value : [value];
        values.filter(Boolean).forEach(v => {
          imageValues[v] = imageValues[v] || [];
          imageValues[v].push(slot);
        });
      });
      Object.entries(imageValues).forEach(([path, slots]) => {
        if (slots.length > 1) {
          warnings.push("Bild mehrfach zugeordnet: " + fileName(path) + " -> " + slots.join(", "));
        }
      });

      return { errors, warnings, missingForPartner };
    }

    function renderChecks() {
      const checks = analyzeCurrentData();
      renderWarnings(checks);
      byId("partnerEmail").value = buildPartnerEmail(checks);
      refreshPreview();
    }

    function buildPartnerEmail(checks) {
      const partner = (currentData.text && currentData.text.partner_name) || currentData.partner || "[Partner]";
      if (!checks.missingForPartner.length) {
        return "Hallo,\n\n" +
          "vielen Dank für die Zusendung der Daten. Beim ersten Durchschauen sind aktuell keine zwingend fehlenden Pflichtinformationen aufgefallen. Wir prüfen die Unterlagen nun weiter für die Layout-Erstellung.\n\n" +
          "Viele Grüße";
      }
      return "Hallo,\n\n" +
        "vielen Dank für die Zusendung der Daten für " + partner + ". Beim Durchschauen ist uns aufgefallen, dass für die weitere Erstellung des Print-Mailings noch folgende Punkte fehlen bzw. geprüft werden müssten:\n\n" +
        checks.missingForPartner.map(item => "- " + item).join("\n") +
        "\n\nKönnt ihr uns die fehlenden Informationen bzw. Dateien bitte noch nachreichen?\n\n" +
        "Vielen Dank und viele Grüße";
    }

    function fieldLabel(key) {
      return fieldLabels[key] || key;
    }

    function buildCheckReport() {
      const checks = analyzeCurrentData();
      const lines = [];
      lines.push("CMC Mailing-Assistent Checkreport");
      lines.push("Partner: " + (currentData.partner || ""));
      lines.push("");
      lines.push("Fehler / fehlende Pflichtpunkte:");
      lines.push(checks.errors.length ? checks.errors.map(x => "- " + x).join("\n") : "- keine");
      lines.push("");
      lines.push("Warnungen / Prüfpunkte:");
      lines.push(checks.warnings.length ? checks.warnings.map(x => "- " + x).join("\n") : "- keine");
      lines.push("");
      lines.push("Partner-Rückfrage:");
      lines.push(byId("partnerEmail").value);
      return lines.join("\n");
    }

    function refreshPreview() {
      byId("jsonPreview").textContent = JSON.stringify(dataForExport(), null, 2);
    }

    byId("previewBtn").addEventListener("click", renderChecks);
    byId("copyEmailBtn").addEventListener("click", async () => {
      await navigator.clipboard.writeText(byId("partnerEmail").value);
      byId("copyEmailBtn").textContent = "Kopiert";
      setTimeout(() => byId("copyEmailBtn").textContent = "Rückfrage-Text kopieren", 1200);
    });
    byId("downloadBtn").addEventListener("click", () => {
      refreshPreview();
      const blob = new Blob([JSON.stringify(dataForExport(), null, 2)], { type: "application/json;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      const brand = (currentData.brand || currentData.partner || "partner").replace(/[^a-z0-9]+/ig, "_").replace(/^_+|_+$/g, "");
      a.download = brand + "_all_variants_data.json";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(a.href);
    });
    byId("downloadReportBtn").addEventListener("click", () => {
      const blob = new Blob([buildCheckReport()], { type: "text/plain;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      const brand = (currentData.brand || currentData.partner || "partner").replace(/[^a-z0-9]+/ig, "_").replace(/^_+|_+$/g, "");
      a.download = brand + "_checkreport.txt";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(a.href);
    });

    byId("downloadPromptBtn").addEventListener("click", () => {
      const prompt = buildTextPrompt();
      const blob = new Blob([prompt], { type: "text/plain;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      const partner = ((currentData.text || {}).partner_name || currentData.partner || "Partner")
        .replace(/[^a-z0-9äöüß]+/ig, "_")
        .replace(/^_+|_+$/g, "");
      a.download = partner + "_KI_Textauftrag.txt";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(a.href);
    });

    byId("copyPromptBtn").addEventListener("click", async () => {
      await navigator.clipboard.writeText(buildTextPrompt());
      byId("copyPromptBtn").textContent = "Textauftrag kopiert";
      setTimeout(() => byId("copyPromptBtn").textContent = "KI-Textauftrag kopieren", 1400);
    });

    byId("importAiJsonBtn").addEventListener("click", async () => {
      const file = byId("aiJsonInput").files[0];
      if (!file) {
        alert("Bitte zuerst die JSON-Datei aus der KI-Texterstellung auswählen.");
        return;
      }
      try {
        applyImportedAiData(parseAiJson(await file.text()));
      } catch (error) {
        alert("KI-Ergebnis konnte nicht importiert werden: " + error.message);
        byId("aiImportStatus").textContent = "";
      }
    });

    byId("importAiJsonPasteBtn").addEventListener("click", () => {
      const raw = byId("aiJsonPaste").value.trim();
      if (!raw) {
        alert("Bitte zuerst die JSON-Antwort aus dem KI-Chat einfügen.");
        return;
      }
      try {
        applyImportedAiData(parseAiJson(raw));
      } catch (error) {
        alert("Die eingefügte Antwort konnte nicht übernommen werden: " + error.message);
        byId("aiImportStatus").textContent = "";
      }
    });

    function parseAiJson(raw) {
      let cleaned = String(raw || "").trim();
      if (cleaned.includes("CMC PRINT-MAILING-STUDIE 2027 – KI-TEXTAUFTRAG") ||
          (cleaned.includes("Arbeitsauftrag:") && cleaned.includes("Verbindliches Promptset:"))) {
        throw new Error("Hier wurde der KI-Textauftrag eingefügt. Bitte diesen zuerst zusammen mit dem Partner-ZIP an ChatGPT senden. Anschließend nur die JSON-Antwort von ChatGPT in dieses Feld kopieren.");
      }
      cleaned = cleaned.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
      return JSON.parse(cleaned);
    }

    function applyImportedAiData(imported) {
      const importedText = imported.text || imported;
      if (!importedText || typeof importedText !== "object" || Array.isArray(importedText)) {
        throw new Error("Die Antwort enthält kein gültiges text-Objekt.");
      }
      templateOnlyTextFields.forEach(key => {
        if (Object.prototype.hasOwnProperty.call(importedText, key)) {
          delete importedText[key];
        }
      });
      currentData.text = Object.assign({}, currentData.text || {}, importedText);
      const partnerName = String(currentData.text.partner_name || "").trim();
      if (partnerName) {
        currentData.partner = partnerName + " – Varianten A-D";
        currentData.brand = partnerName.replace(/[^a-z0-9]+/ig, "_").replace(/^_+|_+$/g, "");
        currentData.options = currentData.options || {};
        currentData.options.brandForFilename = partnerName;
      }
      const mailingDate = String(currentData.text.pal_date || "").trim();
      if (mailingDate) {
        currentData.options = currentData.options || {};
        currentData.options.mailingDate = mailingDate;
      }
      currentData.source_notes = currentData.source_notes || {};
      currentData.source_notes.website = byId("websiteUrl").value.trim();
      currentData.source_notes.partner_text_instructions = byId("toneNotes").value.trim();
      renderTextFields();
      renderChecks();
      byId("aiImportStatus").textContent = "Texte übernommen. Bitte Ampeln und Inhalte prüfen.";
    }

    function buildTextPrompt() {
      const controls = {
        website: byId("websiteUrl").value.trim(),
        partnerspezifische_vorgaben: byId("toneNotes").value.trim(),
        verbindliche_begriffe_und_botschaften: byId("mustUse").value.trim(),
        nicht_verwenden: byId("noGos").value.trim(),
        beispieltext_website: byId("websiteSample").value.trim(),
        vorgabe_variante_a: byId("variantNotesA").value.trim(),
        vorgabe_variante_b: byId("variantNotesB").value.trim(),
        vorgabe_variante_c: byId("variantNotesC").value.trim(),
        vorgabe_variante_d: byId("variantNotesD").value.trim(),
      };
      const schema = {};
      Object.keys(currentData.text || {}).forEach(key => {
        if (templateOnlyTextFields.includes(key)) return;
        schema[key] = "";
      });
      const templateOnlyReference = {};
      templateOnlyTextFields.forEach(key => {
        templateOnlyReference[key] = (currentData.text || {})[key] || "";
      });
      return [
        "CMC PRINT-MAILING-STUDIE 2027 – KI-TEXTAUFTRAG",
        "",
        "Arbeitsauftrag:",
        "1. Lies den zusätzlich hochgeladenen Partnerordner vollständig aus.",
        "2. Nutze ausschließlich belegbare Angaben aus Partnerbriefing, bereitgestellten Dateien und der angegebenen Website.",
        "3. Analysiere Tonalität, Wortwahl und Ansprache der Website und übertrage sie in die vier Layoutvarianten.",
        "4. Beachte die Variantenlogik, Feldregeln, Zeichenlimits und festen Platzhalter aus dem Promptset.",
        "5. Erfinde keine Fakten, Produktwirkungen, Auszeichnungen oder Kundenzitate. Kundenzitatfelder bleiben leer, wenn keine echten Zitate mit Namen vorliegen.",
        "6. Schreibe Template-Felder nicht neu. Sie bleiben im InDesign-Template erhalten und werden nur über Platzhalter befüllt.",
        "7. Gib ausschließlich valides JSON im folgenden Format zurück: {\"text\": {...}}. Keine Erläuterung und keinen Markdown-Codeblock ausgeben.",
        "",
        "Hochgeladener Partnerordner:",
        currentUploadName || "[Dateiname nicht bekannt]",
        "",
        "Partnerspezifische Steuerung:",
        JSON.stringify(controls, null, 2),
        "",
        "Benötigte Textfelder:",
        JSON.stringify(schema, null, 2),
        "",
        "Diese Felder sind Template-Texte und dürfen NICHT frei neu formuliert werden. Wenn sie in der Antwort auftauchen, werden sie ignoriert. Im InDesign-Template werden nur enthaltene Platzhalter wie {{partner_name}}, {{Vorname}}, {{offer_value_amount}} ersetzt:",
        JSON.stringify(templateOnlyReference, null, 2),
        "",
        "Zeichenregeln:",
        JSON.stringify(textRules, null, 2),
        "",
        "Bestehende Werte dienen nur als Struktur- und Platzhalterreferenz. Partnerbezogene Inhalte müssen aus den hochgeladenen Quellen neu abgeleitet werden:",
        JSON.stringify(currentData.text || {}, null, 2),
        "",
        "Verbindliches Promptset:",
        promptSet,
      ].join("\n");
    }

    function dataForExport() {
      const clone = JSON.parse(JSON.stringify(currentData || {}));
      clone.text = clone.text || {};
      templateOnlyTextFields.forEach(key => {
        if (Object.prototype.hasOwnProperty.call(clone.text, key)) {
          clone.text[key] = "";
        }
      });
      clone.options = clone.options || {};
      clone.options.preserveTemplateTextForEmptyValues = true;
      return clone;
    }

    function fileName(path) {
      return String(path).split(/[\/\\]/).pop();
    }

    function escapeHtml(value) {
      return String(value).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
    }
  </script>
</body>
</html>
"""

FAVICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="12" fill="#183f47"/>
  <text x="32" y="39" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" fill="#ffffff">JSON</text>
  <circle cx="50" cy="14" r="6" fill="#2f8f83"/>
</svg>"""


if __name__ == "__main__":
    os.chdir(str(ROOT))
    server = HTTPServer(("127.0.0.1", PORT), Handler)
    print(f"CMC Mailing-Assistent läuft auf http://127.0.0.1:{PORT}")
    print("Zum Beenden dieses Fenster schließen oder Ctrl+C drücken.")
    server.serve_forever()
