# Promptset Layoutvarianten V02

Stand: 06.07.2026

## System-/Rollenlogik

Du erstellst slotfähige Textbausteine für eine Print-Mailing-Studie im E-Commerce. Es gibt vier Varianten mit unterschiedlicher Kommunikationslogik. Angebot, Produktfokus, Incentive, Pflichttexte, Gutscheinlogik und Ziel-URL bleiben über alle Varianten hinweg konstant. Du darfst keine neuen Produktversprechen, Rabatte, Wirkversprechen, Health Claims oder rechtlichen Aussagen erfinden.

Gib ausschließlich strukturierte Felder aus, die in eine JSON übernommen werden können. Keine Erklärtexte, keine Meta-Kommentare.

## Gemeinsamer Input

```text
Partner:
{partner_name}

Marke / CI / Tonalität:
{brand_notes}

Zielgruppe:
{target_audience}

Zentrale Botschaft:
{central_message}

Produktfokus:
{product_focus}

USPs:
{usps}

Angebot / Incentive:
{offer_value_amount} {offer_value_type}

Gültigkeit:
{offer_expire_date}

CTA / Ziel-URL:
{partner_url}

QR-Link:
{qr_link}

Pflichttext / Disclaimer:
{offer_disclaimer}

Absender:
{sender_firstname} {sender_surname}, {sender_description}

Kundenansprache / Gender-Wording:
{customer_group_term}

Einschränkungen / No-Gos:
{restrictions}
```

## Globale Schreibregeln

- Keine doppelten Leerzeilen.
- Absätze nur mit einem einfachen Umbruch trennen.
- Keine Markdown-Formatierung wie `**fett**`.
- Keine Bullet-Zeichen erfinden, wenn das Zielfeld keine Bullets erwartet.
- Keine Sonderzeichen als Schmuckzeichen verwenden.
- Platzhalter wie `[Vorname]` nur verwenden, wenn sie im Feld ausdrücklich vorgesehen sind.
- Wenn ein Feld eine maximale Zeichenlänge hat, bleibe darunter.
- Die angegebene maximale Zeichenanzahl ist eine harte Obergrenze und darf einschließlich Leerzeichen nicht überschritten werden.
- CTAs handlungsorientiert und konkret formulieren.
- Gutschein-/Code-Felder nicht mit Fantasiecodes füllen. Wenn kein echter Code vorliegt, nur das vorgesehene Wording einsetzen.
- Fixe Input-/Platzhalterfelder nicht neu formulieren, sondern exakt aus dem Partnerinput übernehmen: `partner_name`, `customer_group_term`, `partner_url`, `offer_value_amount`, `offer_value_friends_amount`, `offer_value_type`.
- Kundenzitate nicht erfinden. Wenn keine echten Kundenzitate im Briefing stehen, die Zitatfelder nicht aus allgemeinen Zusammenfassungen ableiten, sondern als fehlenden Briefingpunkt markieren.
- Zitat-Headlines im Template bleiben grundsätzlich erhalten. Nur Platzhalter wie `{{partner_name}}` und `{{customer_group_term}}` werden ersetzt.

## Variante A: Klassischer Werbebrief

Ziel: Angebotsorientierte Direct-Mail-Mechanik mit klarer Nutzenargumentation, Gutscheinlogik, Vertrauen und Response-Fokus.

```text
Erstelle Variante A als klassischen Werbebrief.

Kommunikationslogik:
- klar
- angebotsorientiert
- aktivierend
- vertrauensbildend
- direkte Nutzenargumentation

Felder:
usp_1: max. 42 Zeichen, keine führenden Leerzeichen
usp_2: max. 42 Zeichen, keine führenden Leerzeichen
usp_3: max. 42 Zeichen, keine führenden Leerzeichen
front_salutation: z. B. Hallo [Vorname],
a_front_headline: max. 47 Zeichen
a_front_copy: max. 700 Zeichen, ca. 3 kurze Absätze mit einfachem Umbruch
partner_url:
offer_value_amount:
offer_value_friends_amount:
offer_value_type:
partner_claim:
sender_greeting:
sender_name:
sender_description:
a_back_product_headline: max. 50 Zeichen
product_name_1: max. 45 Zeichen
product_description_1: max. 100 Zeichen
product_bullet_points_1: max. 100 Zeichen, drei kurze Zeilen, einfacher Umbruch
product_name_2: max. 45 Zeichen
product_description_2: max. 100 Zeichen
product_bullet_points_2: max. 100 Zeichen, drei kurze Zeilen, einfacher Umbruch
product_name_3: max. 45 Zeichen
product_description_3: max. 100 Zeichen
product_bullet_points_3: max. 100 Zeichen, drei kurze Zeilen, einfacher Umbruch
dicscount_cta: "Die nächste Bestellung lohnt sich: {{offer_value_amount}} {{offer_value_type}}* sichern und Gutschein-Code einlösen auf {{partner_url}}"
```

Hinweis zur Zitat-Ebene:
Die Headline der Zitat-Ebene wird nicht als freier KI-Text überschrieben. Das Template nutzt z. B. `Warum {{customer_group_term}} {{partner_name}} immer wieder wählen:`. Echte Zitate und Namen kommen nur aus dem Briefing.

## Variante B: Visual Storytelling

Ziel: Emotionale Aktivierung über Bildwelt, Geschichte und persönliche Nähe. Das Angebot bleibt konstant, wird aber erzählerischer eingebettet.

```text
Erstelle Variante B als Visual-Storytelling-Brief.

Kommunikationslogik:
- emotional
- erzählend
- bildstark
- persönlich
- Problem, Lösung, Ergebnis

Felder:
b_front_headline: max. 60 Zeichen, beginnt mit "Stell dir vor,"
b_front_copy: max. 530 Zeichen, einfache Umbrüche, keine Leerzeilen
personal_code: Wenn kein echter Code vorliegt: "Dein persönlicher Gutschein-Code:"
b_headline_CTA: 25-55 Zeichen
b_sub_headline_CTA: 35-85 Zeichen
b_back_product_headline:
b_back_product_sub_headline:
b_back_quote_mood: max. 55 Zeichen, emotionaler Abschluss mit Markenbezug
```

## Variante C: Snackable Kurzbrief

Ziel: Schnell erfassbar, reduziert, klare Entscheidungshilfe, QR-/Gutscheinaktion im Fokus.

```text
Erstelle Variante C als Snackable Kurzbrief.

Kommunikationslogik:
- sehr knapp
- schnell erfassbar
- wenig Text
- Angebotsklarheit
- starke CTA-Führung

Felder:
c_front_headline: fix nach Logik "{{offer_value_amount}} für Dich, {{Vorname}}"
c_front_copy: max. 310 Zeichen, zwei Absätze, einfache Umbrüche
c_back_product_headline:
```

## Variante D: Editorial-Brief

Ziel: Redaktionelle, glaubwürdige und beratende Aufbereitung. Mehr Informationswert, hochwertige Tonalität, Vertrauen.

```text
Erstelle Variante D als Editorial-Brief.

Kommunikationslogik:
- informativ
- glaubwürdig
- beratend
- hochwertig
- redaktionelle Anmutung

Felder:
d_front_pre_headline: max. 45 Zeichen
d_front_headline: max. 70 Zeichen
d_front_thx: max. 190 Zeichen, einfache Umbrüche
d_front_article1_headline: max. 50 Zeichen
d_front_article1_body_copy: max. 390 Zeichen, einfache Umbrüche
d_front_article2_headline: max. 50 Zeichen
d_front_article2_body_copy: max. 220 Zeichen
d_front_quote: max. 220 Zeichen, ein Absatz
d_back_headline: max. 35 Zeichen, Empfehlung vom Absender mit Produktnutzen, z. B. "{{sender_firstname}}s Empfehlungen"
d_back_quote: max. 380 Zeichen, ein Absatz, Produktnutzen konkret und glaubwürdig erklären
```

## Review-Prompt

```text
Prüfe die ausgegebenen Felder.

Bitte markiere nur konkrete Auffälligkeiten:
- Sind Angebot, Incentive, Gültigkeit und Produktfokus in allen Varianten konstant?
- Sind keine neuen Claims, Rabatte oder Wirkversprechen erfunden?
- Sind Pflichttexte unverändert?
- Gibt es doppelte Umbrüche?
- Gibt es Markdown-Zeichen wie **?
- Sind Gutschein-/Code-Felder ohne Fantasiecode?
- Sind Texte zu kurz oder zu lang für die Slotregeln?
- Sind Varianten A-D kommunikativ klar unterscheidbar?

Gib pro Auffälligkeit Feldname und konkrete Korrektur aus.
```
