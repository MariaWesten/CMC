#!/bin/zsh
cd "$(dirname "$0")"
export CMC_JSON_BUILDER_PORT=8766
python3 server.py &
SERVER_PID=$!
sleep 1
open "http://127.0.0.1:8766"
wait $SERVER_PID
