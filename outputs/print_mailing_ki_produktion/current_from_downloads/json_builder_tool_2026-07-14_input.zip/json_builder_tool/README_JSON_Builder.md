# CMC Mailing-Assistent

Stand: 09.07.2026

## Zweck

Der CMC Mailing-Assistent ist ein lokaler Prototyp, mit dem Jule und Simone eine Partner-ZIP prüfen, einen standardisierten KI-Textauftrag erstellen, KI-Texte übernehmen, Bildslots zuordnen und daraus eine JSON-Datei für das InDesign-Skript exportieren können.

Das Tool ist als Standalone-Paket gedacht: Die Basis-JSON liegt im Builder-Ordner, sodass kein zusätzlicher Shape-labs-Testordner auf dem Rechner vorhanden sein muss.

## Start

1. Datei `start_partner_json_builder.command` doppelklicken.
2. Im Browser öffnet sich `http://127.0.0.1:8766`.
3. Partner-ZIP auswählen und analysieren.
4. Automatisch erkannte Website prüfen und optionale partnerspezifische Textvorgaben eintragen.
5. `KI-Textauftrag herunterladen` wählen.
6. Partner-ZIP im freigegebenen KI-Chat hochladen und den kopierten Textauftrag als Nachricht einfügen.
7. Die vollständige JSON-Antwort kopieren und in das Feld `JSON-Antwort aus dem KI-Chat einfügen` einsetzen.
8. Texte, Ampeln und Bildslots prüfen.
9. Rückfrage-Text und Checkreport prüfen.
10. InDesign-JSON herunterladen.

## Aktueller Funktionsumfang

- ZIP-Upload.
- Bilddateien werden erkannt und lokal in einen eigenen Unterordner unter `assets_partner` kopiert. Dadurch überschreiben sich die Bilder verschiedener Partner nicht.
- Bilder werden anhand von Dateinamen automatisch vorgeschlagen, z. B. `partner_logo.png`, `img_product_1.jpg`, `sender_image.png` oder `mood_first_page.jpg`.
- Bildpfade werden als absolute lokale Pfade in die JSON geschrieben, damit InDesign sie auch findet, wenn die exportierte JSON z. B. im Downloads-Ordner liegt.
- Pro Bildslot wird ein Bild zugeordnet. Wenn mehrere unterschiedliche Bilder benötigt werden, müssen die Rahmen in InDesign eindeutige Slotnamen haben.
- Alle Textfelder sind sichtbar und editierbar.
- Der standardisierte KI-Textauftrag enthält Variantenlogik, Feldnamen, Zeichenlimits und partnerspezifische Vorgaben.
- Die Partnerwebsite wird aus Text- und Office-Dateien im Briefing nach Möglichkeit automatisch erkannt und vorausgefüllt.
- Zusätzlich zu globalen Vorgaben können bei Bedarf eigene Hinweise für A, B, C und D ergänzt werden.
- Der KI-Textauftrag kann als Datei heruntergeladen oder direkt in die Zwischenablage kopiert werden.
- KI-Ergebnisse im Format `{"text": {...}}` können importiert werden; Bildpfade und technische Optionen bleiben dabei erhalten.
- Die JSON-Antwort kann direkt aus dem KI-Chat eingefügt werden. Eine separate JSON-Datei ist nur noch eine alternative Importmöglichkeit.
- Markenname und Mailingdatum aus dem KI-Ergebnis werden für den Namen der gespeicherten InDesign-Datei übernommen.
- Die Tonalität kann über Website, Beispieltext, verbindliche Botschaften und No-Gos je Partner gesteuert werden.
- Textfelder zeigen eine einfache Ampel: fehlend, okay oder zu lang.
- Die Rahmentabelle liefert ausschließlich harte Maximalzeichen inklusive Leerzeichen. Es werden keine Mindestlängen oder Zielspannen erzwungen.
- Fixe Inputfelder wie `partner_name`, `customer_group_term`, `partner_url`, `offer_value_amount`, `offer_value_friends_amount` und `offer_value_type` werden als feste Platzhalter-/Angebotswerte behandelt.
- Pflichtfelder, Pflichtbilder, sichtbare Platzhalter und doppelte Umbrüche werden geprüft.
- Ein Rückfrage-Text an den Partner wird automatisch vorgeschlagen und kann kopiert werden.
- Ein Checkreport kann als Textdatei heruntergeladen werden.
- JSON kann exportiert werden.

## Bewusst getrennt

- Die eigentliche Texterzeugung läuft derzeit im freigegebenen KI-Chat. Der Mailing-Assistent erzeugt dafür den vollständigen Textauftrag und importiert das Ergebnis.
- Eine direkte API-Schaltfläche kann später ergänzt werden. Für den aktuellen Prototyp bleibt die KI-Ausführung getrennt, damit keine Zugangsdaten im Tool gespeichert werden und der Prüf-/Exportprozess stabil bleibt.
- Noch kein automatisches Entpacken eines kompletten InDesign-Testpakets.
- Noch keine PDF-Vorschau.
- Noch keine direkte SharePoint-Anbindung.

## Hinweise zu Zitatfeldern

Die Zitat-Headline sollte im InDesign-Template als Template-Text stehen, z. B. `Warum {{customer_group_term}} {{partner_name}} immer wieder wählen:`. Das Skript ersetzt dann nur die Platzhalter und überschreibt nicht die komplette Headline.

Echte Kundenzitate dürfen aus dem Briefing oder eindeutig belegbar von der Partnerwebsite übernommen werden. Wenn keine echten Zitate vorliegen, werden die Felder als fehlend markiert und nicht frei erfunden.

Leere Textwerte überschreiben im InDesign-Skript keinen vorhandenen Template-Inhalt mehr.

Zitatbilder können über die Slots `img_quote_1` und `img_quote_2` zugeordnet werden. Für den MVP ist die manuelle Auswahl im Builder zuverlässiger als eine automatische KI-Auswahl nach Zielgruppe.

## Strategische Rolle

Das Tool soll die operative JSON-Erstellung für Jule und Simone zugänglich machen. Die Prozesslogik, Qualitätsregeln, Promptlogik und Weiterentwicklung bleiben ein zentraler Steuerungspunkt.
